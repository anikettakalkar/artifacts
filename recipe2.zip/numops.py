def inverse(n):
    result = 1/n
    print(result)
    return result 
def double(n):
    result = n*2
    print(result)
    return result 
def negative(n):
    result = n * -1
    print(result)
    return result 
def factorial(n):
    import math
    result = math.factorial(n)
    print(result)
    return result 
def echo(data):
    print("In Print Result : ")
    print(data)
    return data

from mlrun.runtimes import nuclio_init_hook
def init_context(context):
    nuclio_init_hook(context, globals(), 'serving_v2')

def handler(context, event):
    return context.mlrun_handler(context, event)