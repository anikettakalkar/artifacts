def add(a,b):
    result = a+b
    print(result)
    return result 
def sub(a,b):
    result = a-b
    print(result)
    return result 
def mul(a,b):
    result = a*b
    print(result)
    return result 
def div(a,b):
    result = a/b
    print(result)
    return result 
def sqr(n):
    result = n*n
    print(result)
    return result
def echo(data):
    print("In Print Result : ")
    print(data)
    return data

from mlrun.runtimes import nuclio_init_hook
def init_context(context):
    nuclio_init_hook(context, globals(), 'serving_v2')

def handler(context, event):
    return context.mlrun_handler(context, event)